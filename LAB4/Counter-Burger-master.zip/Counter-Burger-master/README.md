# Counter Burger
Solution for getting the Price of a “Custom Built Burger” using the Decorator Pattern.